/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bbank;


//import bbank.Role.AdminRole;
//import bbank.Role.BbankRole;

import bbank.Role.DonarRole;
import bbank.UserAccount.UserAccount;

import bbank.WorkQueue.WorkRequest;
import bbank.Donor.DeliveryManDirectory;
import bbank.user;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

/**
 *
 * @author akhil
 */
public class ConfigureABusiness {
     private bbank.Donor.DeliveryManDirectory ddirectory;
    //private 
    public static Bbank configure() {
      
    
         return null;
      
    
}
}
